<?php
	  echo "<br/>														
																						<br/>
																						<br/></p> ";
     echo '<img height="80" width="80"  vspace="15" hspace="15" border="0" align="left" src="../.././resim/warning.png" />'."<br>Dikkat Tek Seçim Yapınız<br>";
?>