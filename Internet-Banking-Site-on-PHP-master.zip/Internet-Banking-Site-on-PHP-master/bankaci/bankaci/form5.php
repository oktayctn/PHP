<?php
    // $_POST['id'] will return an array.
    $selected_values = $_POST['name'];//$_REUEST['name'] ilede alınabilirdi
	echo "Burası form5 phpdir ".$selected_values;
	

?>