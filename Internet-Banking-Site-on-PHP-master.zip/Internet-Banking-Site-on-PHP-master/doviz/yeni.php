<?php

echo "yeni bir dosya";

?>

fsdfsd
      <? echo "yazi"; ?>