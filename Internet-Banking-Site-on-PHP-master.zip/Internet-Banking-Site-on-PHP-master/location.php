


<html lang="en">
<head>

   <meta charset="UTF-8">
  
   
  
  
   
</head>
<body>
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d755.7360971218667!2d30.331852985123387!3d40.74124918742079!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14ccaded7bb0e589%3A0x206f818fad5b3670!2sSakarya+%C3%9Cniversitesi!5e0!3m2!1str!2s!4v1430324246700" width="800" height="600" frameborder="0" style="border:0"></iframe>
</body>
</html>